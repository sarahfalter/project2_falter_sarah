<script type="text/javascript">
002
$(function(){
003
$("#demo").elastic_grid({
004
'filterEffect': '<a href="https://www.jqueryscript.net/tags.php?/popup/">popup</a>', // moveup, scaleup, fallperspective, fly, flip, helix , popup
005
'hoverDirection': true,
006
'hoverDelay': 0,
007
'hoverInverse': false,
008
'expandingSpeed': 500,
009
'expandingHeight': 500,
010
'items' :
011
[
012
{
013
'title' : 'Art Gallery Website',
014
'description'   : 'Art Gallery website designed and developed by Sarah Falter. Skills showcased: HTML5, CSS3, Javascript, Logo Design, Mobile-First Responsive Web Design, Brand Identity',
015
'thumbnail' : ['images/portfolio-small-1.png', 'images/portfolio-small-2.png'],
016
'large' : ['images/portfolio-large-1.png', 'images/portfolio-large-2.png'],
017
'button_list'   :
018
[
019
{ 'title':'Launch Site', 'url' : '' },
020

021
],
022
'tags'  : ['Web Projects']
023
},
024
{
025
'title' : 'Coffee Shop Website',
026
'description'   : 'Coffee Shop Landing Page designed and developed by Sarah Falter. Skills showcased: HTML5, CSS3, Javascript, Logo Design, Mobile-First Responsive Web Design, Brand Identity',
027
'thumbnail' : ['images/portfolio-small-10.png', 'images/portfolio-small-8.png'],
028
'large' : ['images/portfolio-large-10.png', 'images/portfolio-large-8.png'],
029
'button_list'   :
030
[
031
{ 'title':'Demo', 'url' : '' },
032

033
],
034
'tags'  : ['Web Projects']
035
},
036
{
037
'title' : 'Portiko Technologies',
038
'description'   : 'A complete brand identity for up and coming technology company, Portiko Technologies. This brand identity was designed and developed by Sarah Falter from the research to final product. The visual identity consists of a style guide, proposed logo, corporate brand materials and print designs, and web design. Skills showcased: Brand Identity Development, Logo Design, Print Design, Web Design. HTML5, CSS3, Adobe XD, Adobe Illustrator, Adobe InDesign',
039
'thumbnail' : ['images/portfolio-small-4.png', 'images/portfolio-small-5.png', 'images/portfolio-small-6.png', 'images/portfolio-small-7.png'],
040
'large' : ['images/portfolio-large-4.png','images/portfolio-large-5.png', 'images/portfolio-large-6.png', 'images/portfolio-large-7.png'],
041
'button_list'   :
042
[
043
{ 'title':'Demo', 'url' : '' },
044

045
],
046
'tags'  : ['Web Projects', 'Design']
047
},
048
{
049
'title' : 'The Met Brochure',
050
'description'   : 'Proposed brochure design for the Metropolitan Museum of Art. Please note this is for academic purposes. Skills showcased: Design Research, Visual Communication, Print Design. Adobe InDesign.',
051
'thumbnail' : ['images/portfolio-small-3'],
052
'large' : ['images/portfolio-large-3'],
053
'button_list'   :
054
[
055
{  },
056
{ }
057
],
058
'tags'  : ['Design']
059
},
060
{
061
'title' : 'Gone Girl Redesign',
062
'description'   : 'A reimagined and designed cover for the best-selling novel, Gone Girl.',
063
'thumbnail' : ['images/portfolio-small-9'],
064
'large' : ['images/portfolio-large-9'],
065
'button_list'   :
066
[
067

191
}
192

193
]
194
});
195
});
196
</script>
