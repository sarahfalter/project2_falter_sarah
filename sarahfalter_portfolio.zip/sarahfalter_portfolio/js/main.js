

$("#container").backstretch([
  { width: 200, url: "images/portfolio5.png" },
  { width: 200, url: "images/portfolio6.png" },
  { width: 200, url: "images/portfolio3.jpg" },
  { width: 200, url: "images/portfolio4.png" },
], {duration: 4000, transition:"fade", transitionDuration: 1000});
